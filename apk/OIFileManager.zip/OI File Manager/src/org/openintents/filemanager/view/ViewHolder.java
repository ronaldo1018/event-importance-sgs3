package org.openintents.filemanager.view;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
	public ImageView icon;
	public TextView primaryInfo;
	public TextView secondaryInfo;
	public TextView tertiaryInfo;
}